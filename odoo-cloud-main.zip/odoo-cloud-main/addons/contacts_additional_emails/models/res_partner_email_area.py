# -*- coding: utf-8 -*-
from odoo import models, fields


class ResPartnerEmailArea(models.Model):
    _name = 'res.partner.email.area'
    _description = 'Partner Email Area'

    name = fields.Char(string='Name', required=True)
    description = fields.Text(string='Description')
