# -*- coding: utf-8 -*-
from . import res_partner
from . import res_partner_email
from . import res_partner_email_area
from . import mail_template
